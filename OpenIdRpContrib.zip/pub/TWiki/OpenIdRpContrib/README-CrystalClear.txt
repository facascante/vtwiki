Crystal Clear icons are by author/artist Everaldo Coelho licensed under the
GNU Lesser General Public License (LGPL).  Icons from that collection in
this TWiki source directory (which may also be seen on TWiki installations
as the pub/TWiki/OpenIdRpContrib directory) are named with the prefix
"Crystal_Clear_".

For all the icons, see the Open Icon Library on SourceForge.Net at
http://openiconlibrary.sourceforge.net/

For the LGPL license text see http://www.gnu.org/copyleft/lesser.html
